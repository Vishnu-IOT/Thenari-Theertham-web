import { Link } from 'react-router-dom'
import { Kasavu } from './Ornaments.jsx'
import { navLinks, templeData as t } from '../data/templeData.js'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="site-footer">
      <div className="container footer-grid">
        <section className="footer-brand" aria-label="Temple details">
          <p className="footer-kicker">A place of worship in Thenari</p>
          <h2>{t.name}</h2>
          <p className="footer-sub">{t.subtitle}</p>
          <p className="footer-mantra" lang="sa">&#x0950; &#x0936;&#x094D;&#x0930;&#x0940; &#x0930;&#x093E;&#x092E; &#x0950;</p>
        </section>

        <nav className="footer-nav" aria-label="Footer navigation">
          <h3>Explore</h3>
          <ul>{navLinks.map((l) => <li key={l.to}><Link to={l.to}>{l.label}</Link></li>)}</ul>
        </nav>

        <section className="footer-visit" aria-labelledby="footer-visit-title">
          <h3 id="footer-visit-title">Plan your visit</h3>
          <address>{t.contact.address}</address>
          <p className="footer-hours">Darshan<br /><span>{t.timings.morning}</span><br /><span>{t.timings.evening}</span></p>
          <div className="footer-actions">
            {t.contact.phone && <a href={`tel:${t.contact.phone.replace(/[^+\d]/g, '')}`}>Call the temple <span aria-hidden="true">&#8599;</span></a>}
            {t.location.mapUrl && <a href={t.location.mapUrl} target="_blank" rel="noreferrer">Get directions <span aria-hidden="true">&#8599;</span></a>}
          </div>
          {t.social.length > 0 && <ul className="footer-social">{t.social.map((s) => <li key={s.label}><a href={s.url} target="_blank" rel="noreferrer">{s.label}</a></li>)}</ul>}
        </section>
      </div>
      <Kasavu />
      <div className="copyright">
        <p>&#169; {year} {t.name} <span aria-hidden="true">&#183;</span> {t.subtitle}</p>
        <Link to="/privacy">Privacy</Link>
      </div>
    </footer>
  )
}
