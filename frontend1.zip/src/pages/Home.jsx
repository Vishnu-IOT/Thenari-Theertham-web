import { Link } from "react-router-dom";
import { usePageMeta, Reveal } from "../components/Common.jsx";
import { HeritageIntro } from "../components/Sections.jsx";
import { Nilavilakku, Kasavu, TempleTitle, Mandala } from "../components/Ornaments.jsx";
import { templeData as t, deities, festivals, gallery } from "../data/templeData.js";

export default function Home() {
  usePageMeta(
    "Thenari Theertham | Sree Madhyarani Sree Rama Temple",
    "Discover Thenari Theertham, Sree Madhyarani Sree Rama Temple — a sacred place of devotion, heritage and tradition.",
  );
  const picks = gallery.filter((_, i) => i % 3 === 0).slice(0, 4);

  return (
    <div className="home-trad">
      {/* ---------- SANCTUM HERO ---------- */}
      <section className="sanctum-hero" aria-labelledby="hero-title">
        {/* <Mandala className="sh-mandala" /> */}
        <div className="container sh-grid">
          <Nilavilakku className="sh-lamp left" />
          <div className="sh-text">
            <p className="sh-mantra" lang="sa">॥ श्री राम जय राम जय जय राम ॥</p>
            <h1 id="hero-title">{t.name}</h1>
            <p className="sh-sub">{t.subtitle}</p>
            <Kasavu />
            <p className="sh-tag">{t.tagline}</p>
            <div className="btn-row">
              <Link className="btn btn-gold" to="/temple">Enter the Sanctum</Link>
              <Link className="btn btn-ghost" to="/visit">Plan Your Visit</Link>
            </div>
          </div>
          <div className="sh-arch">
            <div className="arch-door">
              <img
                src="/images/temple/heritage.png"
                alt="Golden sculpture of Sree Rama holding a bow"
                width="600"
                height="600"
              />
            </div>
          </div>
          <Nilavilakku className="sh-lamp right" />
        </div>
        <Kasavu thick />
      </section>

      {/* ---------- DARSHAN BOARD ---------- */}
      <section className="darshan-board" aria-label="Darshan timings">
        <div className="container db-row">
          <p className="db-title">Darshan</p>
          <p><strong>Morning</strong> {t.timings.morning}</p>
          <span aria-hidden="true">🪔</span>
          <p><strong>Evening</strong> {t.timings.evening}</p>
          <Link to="/pooja-seva">Offerings</Link>
        </div>
      </section>

      {/* ---------- HERITAGE (original component, unchanged) ---------- */}
      <HeritageIntro />

      {/* ---------- THEERTHAM TEASER ---------- */}
      <section className="home-water">
        <div className="container hw-grid">
          <Reveal className="hw-photo">
            <img src="/images/temple/boat-god.png" alt="Sacred water of Thenari Theertham" loading="lazy" />
          </Reveal>
          <Reveal className="hw-text">
            <p className="hw-small">The sacred waters</p>
            <h2>{t.theertham.quote}</h2>
            <p>{t.theertham.text}</p>
            <Link className="btn btn-gold" to="/theertham">Visit the Theertham</Link>
          </Reveal>
        </div>
      </section>

      {/* ---------- DEITIES: THREE SANCTUM NICHES ---------- */}
      <section className="section home-deities">
        <div className="container">
          <TempleTitle small="Sanctum" title="Temple Deities" />
          <ul className="niche-row">
            {deities.map((d) => (
              <li key={d.name} className="niche">
                <div className="niche-arch"><img src={d.image} alt={d.name} loading="lazy" /></div>
                <h3>{d.name}</h3>
              </li>
            ))}
          </ul>
          <p className="center"><Link className="btn btn-maroon" to="/temple">About the Temple</Link></p>
        </div>
      </section>

      {/* ---------- FESTIVAL BANNERS ---------- */}
      <section className="home-fest">
        <div className="container">
          <TempleTitle small="Celebrations" title="Festivals & Events" tone="light" />
          <ul className="kodi-row">
            {festivals.slice(0, 4).map((f) => (
              <li key={f.name} className="kodi"><span>{f.name}</span><small>{f.date}</small></li>
            ))}
          </ul>
          <p className="center"><Link className="btn btn-gold" to="/festivals">Festival Calendar</Link></p>
        </div>
      </section>

      {/* ---------- GALLERY STRIP ---------- */}
      <section className="section home-gallery">
        <div className="container">
          <TempleTitle small="Darshan in pictures" title="Gallery" />
          <ul className="frame-strip">
            {picks.map((g) => (
              <li key={g.id}><div className="mini-frame"><img src={g.src} alt={g.alt} loading="lazy" /></div></li>
            ))}
          </ul>
          <p className="center"><Link className="btn btn-maroon" to="/gallery">Open the Gallery</Link></p>
        </div>
      </section>

      {/* ---------- CLOSING INVITATION ---------- */}
      <section className="home-invite">
        <div className="container">
          <p className="hi-mal" lang="ml">ശ്രീ രാമ ജയം</p>
          <p>{t.contact.address}</p>
          <p className="btn-row">
            <Link className="btn btn-gold" to="/visit">How to Reach</Link>
            <Link className="btn btn-ghost" to="/contact">Contact the Temple</Link>
          </p>
        </div>
      </section>
    </div>
  );
}
