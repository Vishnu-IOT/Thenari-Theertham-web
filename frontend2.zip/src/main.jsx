import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import './styles/global.css'
import './styles/base.css'
import './styles/heritage.css'
import './styles/pages.css'
createRoot(document.getElementById('root')).render(<BrowserRouter><App /></BrowserRouter>)
